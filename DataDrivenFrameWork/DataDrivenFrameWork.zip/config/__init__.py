#!usr/bin/env python
#-*- coding:utf-8 -*-
"""
@author:fengg
@file: __init__.py.py
@time: 2020/07/11
"""


def func():
    pass


class Main():
    def __init__(self):
        pass


if __name__ == "__main__":
    pass